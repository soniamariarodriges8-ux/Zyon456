import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Pressable, StyleSheet, Linking, Alert } from 'react-native';
import Slider from '@react-native-community/slider';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORE = 'zyon_xit45_settings';
const DEFAULTS = { aim: 80, fov: 45, antiShake: true };
const GAME_URL = 'https://apps.apple.com/br/app/free-fire-x-naruto-shippuden/id1300146617';

export default function App() {
  const [settings, setSettings] = useState(DEFAULTS);
  const [ready, setReady] = useState(false);
  useEffect(() => { (async () => {
    try { const saved = await AsyncStorage.getItem(STORE); if (saved) {
      const parsed = JSON.parse(saved);
      setSettings({ aim: Math.max(0, Math.min(120, Number(parsed.aim) || 0)), fov: 45, antiShake: Boolean(parsed.antiShake) });
    }} catch (_) {} finally { setReady(true); }
  })(); }, []);
  useEffect(() => { if (ready) AsyncStorage.setItem(STORE, JSON.stringify(settings)).catch(() => {}); }, [settings, ready]);
  const aimAssist = value => setSettings(s => ({...s, aim: Math.round(value)}));
  const fov45 = () => setSettings(s => ({...s, fov:45}));
  const removerTremedeira = value => setSettings(s => ({...s, antiShake:value}));
  const resetSettings = () => setSettings({...DEFAULTS});
  const abrirFreeFire = async () => { try { await Linking.openURL(GAME_URL); } catch (_) { Alert.alert('Não foi possível abrir', 'Confira sua conexão e tente novamente.'); } };
  return <SafeAreaView style={styles.root}><ScrollView contentContainerStyle={styles.page}>
    <View style={styles.hero}><Text style={styles.logo}>ZYON</Text><Text style={styles.sub}>XIT 45 · ULTIMATE EDITION</Text><Text style={styles.pill}>PAINEL DE CONFIGURAÇÕES</Text></View>
    <View style={styles.card}><Text style={styles.label}>🎯  AIM ASSIST · REFERÊNCIA</Text><Text style={styles.value}>{settings.aim}<Text style={styles.unit}> / 120</Text></Text><Slider minimumValue={0} maximumValue={120} step={1} value={settings.aim} onValueChange={aimAssist} minimumTrackTintColor="#00eaff" maximumTrackTintColor="#30485b" thumbTintColor="#00eaff" /><View style={styles.between}><Text style={styles.muted}>0</Text><Text style={styles.muted}>120 MAX</Text></View></View>
    <View style={styles.card}><Text style={styles.label}>👁  FOV · REFERÊNCIA</Text><Text style={styles.value}>{settings.fov}°</Text><Pressable style={styles.selected} onPress={fov45}><Text style={styles.selectedText}>FOV 45° SELECIONADO</Text></Pressable></View>
    <View style={styles.card}><Text style={styles.label}>⚡  ANTI-SHAKE · REFERÊNCIA</Text><View style={styles.buttons}><Pressable onPress={() => removerTremedeira(true)} style={[styles.option, settings.antiShake && styles.selected]}><Text style={[styles.optionText, settings.antiShake && styles.selectedText]}>ATIVAR</Text></Pressable><Pressable onPress={() => removerTremedeira(false)} style={[styles.option, !settings.antiShake && styles.selected]}><Text style={[styles.optionText, !settings.antiShake && styles.selectedText]}>DESATIVAR</Text></Pressable></View><Text style={styles.status}>{settings.antiShake ? 'ATIVADO NO PAINEL' : 'DESATIVADO NO PAINEL'}</Text></View>
    <View style={styles.card}><Text style={styles.label}>🎮  FREE FIRE</Text><Pressable onPress={abrirFreeFire} style={styles.launch}><Text style={styles.launchText}>ABRIR FREE FIRE ↗</Text></Pressable><Text style={styles.status}>ABRE A PÁGINA OFICIAL DA APP STORE</Text></View>
    <Pressable onPress={resetSettings} style={styles.reset}><Text style={styles.resetText}>RESTAURAR CONFIGURAÇÕES</Text></Pressable>
    <Text style={styles.note}>Este painel salva preferências no aplicativo. Não altera mira, FOV ou tremedeira dentro do Free Fire.</Text><Text style={styles.footer}>ZYON XIT 45 · iOS EDITION</Text>
  </ScrollView></SafeAreaView>;
}
const styles = StyleSheet.create({ root:{flex:1,backgroundColor:'#070b13'},page:{padding:20,paddingBottom:38},hero:{alignItems:'center',paddingVertical:27},logo:{fontSize:46,fontWeight:'900',letterSpacing:7,color:'#00eaff'},sub:{color:'#8da2b5',fontSize:11,letterSpacing:2,marginTop:7},pill:{marginTop:18,borderColor:'#125b69',borderWidth:1,borderRadius:99,paddingVertical:8,paddingHorizontal:15,color:'#48e2e8',fontSize:10,letterSpacing:1},card:{backgroundColor:'#111c2b',borderColor:'#284055',borderWidth:1,borderRadius:18,padding:19,marginBottom:15},label:{fontSize:13,fontWeight:'800',letterSpacing:1,color:'#edfaff',marginBottom:15},value:{color:'#00eaff',fontSize:36,fontWeight:'900',textAlign:'right',marginBottom:10},unit:{fontSize:14,color:'#7895a8'},between:{flexDirection:'row',justifyContent:'space-between'},muted:{color:'#8da2b5',fontSize:11},buttons:{flexDirection:'row',gap:10},option:{flex:1,padding:15,alignItems:'center',borderRadius:12,borderWidth:1,borderColor:'#00bccc',backgroundColor:'#142a3b'},optionText:{color:'#00eaff',fontWeight:'800',fontSize:12},selected:{backgroundColor:'#00eaff',padding:15,borderRadius:12,alignItems:'center'},selectedText:{color:'#061019',fontWeight:'900',fontSize:12},status:{textAlign:'center',color:'#00e6a0',fontSize:11,marginTop:15},launch:{backgroundColor:'#00eaff',borderRadius:13,padding:19,alignItems:'center'},launchText:{color:'#061019',fontSize:15,fontWeight:'900'},reset:{backgroundColor:'#1b2635',borderRadius:12,borderWidth:1,borderColor:'#53657b',padding:16,alignItems:'center'},resetText:{color:'#e7f2ff',fontWeight:'800',fontSize:12},note:{textAlign:'center',color:'#8da2b5',fontSize:12,lineHeight:19,marginTop:24},footer:{textAlign:'center',color:'#5e7589',fontSize:10,marginTop:18} });
