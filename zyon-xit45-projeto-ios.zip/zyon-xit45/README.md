# ZYON XIT 45 — Projeto iOS

Projeto-fonte Expo/React Native. **Não é um IPA compilado.** O painel não altera o Free Fire.

## Compilação na nuvem

1. Transfira estes arquivos para um ambiente com Node.js e terminal (por exemplo, um ambiente de desenvolvimento em nuvem).
2. Execute `npm install` e `npx expo install --fix` para alinhar as dependências com o SDK instalado.
3. Execute `npx eas-cli login`.
4. Execute `npx eas-cli device:create` para registrar o iPhone com sua conta Apple Developer.
5. Execute `npx eas-cli build --platform ios --profile preview`.
6. Quando o build terminar, baixe o `.ipa` pelo painel do Expo.
7. Importe o `.ipa` no ESign e assine com um certificado e perfil de provisionamento válidos para seu dispositivo; então instale.

O EAS pode solicitar uma assinatura ativa no Apple Developer Program e credenciais válidas. O ESign **não** compila código-fonte em IPA e não substitui as exigências de assinatura do iOS.

## Funcionalidades
- Slider de referência Aim Assist de 0 a 120
- Referência FOV 45°
- Botões Anti-Shake de referência
- Preferências persistidas com AsyncStorage
- Botão para página oficial do Free Fire na App Store
- Restaurar configurações

**Nota:** Não foram realizados testes de compilação iOS neste ambiente. Dependências podem precisar ser ajustadas por `npx expo install --fix`.
